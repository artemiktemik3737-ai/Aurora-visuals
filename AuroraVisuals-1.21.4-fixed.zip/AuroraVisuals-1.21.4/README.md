# Aurora Visuals — Minecraft 1.21.4 / Fabric

This source project implements a purple click-GUI inspired by the supplied Pulse Visuals screenshots.

## Controls
- Right Shift: open/close the menu
- Left click a module: toggle it
- Right click a module: select it and open its settings drawer
- Click either slider to adjust its value

## Implemented client-side features
- Click GUI with Visuals / World / HUD / Effects / Interface tabs
- Target ESP: draws box outlines around nearby living entities (players use a red tint; other mobs purple)
- Trails: stores recent positions of living entities and renders fading purple trail markers
- See Invisible: client-side visibility override for living entities
- Watermark, FPS counter and coordinates HUD
- Local snow and rain particles
- World Particles ambient end-rod particles

## Important
This is a client-side visual mod. It does not send packets or change server state.
Many menu entries are still configuration placeholders and do not yet have their own renderer/game hook (for example Motion Blur, Puddles, Reflections, Thunder, Kill Effect, Hit Bubble). The sliders are UI settings and are not yet wired to every effect.

## Build
Requires Java 21 and internet access for Gradle dependencies:
`gradle build`

The resulting JAR is placed in `build/libs/`.
