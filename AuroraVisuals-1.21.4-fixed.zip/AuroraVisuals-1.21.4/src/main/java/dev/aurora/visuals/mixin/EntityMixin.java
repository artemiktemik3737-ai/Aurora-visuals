package dev.aurora.visuals.mixin;

import dev.aurora.visuals.ModuleManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "isInvisibleTo", at = @At("HEAD"), cancellable = true)
    private void aurora$showInvisible(PlayerEntity player, CallbackInfoReturnable<Boolean> cir) {
        if ((Object) this instanceof LivingEntity && ModuleManager.get("See Invisible") != null
                && ModuleManager.get("See Invisible").enabled) {
            cir.setReturnValue(false);
        }
    }
}
