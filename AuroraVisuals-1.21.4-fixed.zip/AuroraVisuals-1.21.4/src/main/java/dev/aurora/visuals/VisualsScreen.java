package dev.aurora.visuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.List;

public class VisualsScreen extends Screen {
    private static final String[] TABS = {"Visuals", "World", "HUD", "Effects", "Interface"};
    private static final int PURPLE = 0xFF8957FF;
    private int tab = 0, scroll = 0, selected = -1;
    private int px, py, pw, ph;
    private List<ModuleManager.VisualModule> visible = List.of();

    public VisualsScreen() { super(Text.literal("Aurora Visuals")); }
    @Override public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0xB9000000);
        pw = Math.min(820, width - 28); ph = Math.min(500, height - 28);
        px = (width-pw)/2; py = (height-ph)/2;
        ctx.fill(px, py, px+pw, py+ph, 0xF00D0F16);
        ctx.fill(px, py, px+pw, py+3, PURPLE);

        // Header
        ctx.fill(px, py+3, px+pw, py+62, 0xFF11131D);
        ctx.drawTextWithShadow(textRenderer, Text.literal("✦  AURORA VISUALS"), px+20, py+17, 0xFFF5F0FF);
        ctx.drawTextWithShadow(textRenderer, Text.literal("VISUAL CLIENT  /  1.21.4"), px+21, py+34, 0xFF858398);
        ctx.drawTextWithShadow(textRenderer, Text.literal("FABRIC  •  RIGHT SHIFT TO CLOSE"), px+pw-205, py+25, 0xFFAAA5BC);

        // Left navigation
        int navX=px+14, navY=py+76;
        ctx.fill(navX, navY, navX+150, py+ph-16, 0xFF11131D);
        ctx.drawTextWithShadow(textRenderer, Text.literal("  NAVIGATION"), navX+9, navY+12, 0xFF77758C);
        for (int i=0;i<TABS.length;i++) {
            int y=navY+34+i*36;
            if (i==tab) ctx.fill(navX+7,y-5,navX+143,y+21,0xFF302344);
            ctx.drawTextWithShadow(textRenderer, Text.literal((i==tab?"✦  ":"   ")+TABS[i]), navX+13,y+2,
                    i==tab?0xFFD7BDFF:0xFFAAA8B9);
        }
        ctx.drawTextWithShadow(textRenderer, Text.literal("AURORA 1.0"), navX+12, py+ph-34, 0xFF6D6A80);

        // Module grid
        int contentX=px+178, contentY=py+79;
        ctx.drawTextWithShadow(textRenderer, Text.literal(TABS[tab].toUpperCase()), contentX, contentY, 0xFFF1EDFF);
        ctx.drawTextWithShadow(textRenderer, Text.literal("Click a module to enable it  •  Right-click for settings"), contentX, contentY+14, 0xFF858397);
        visible=ModuleManager.MODULES.stream().filter(m->m.category.equals(TABS[tab])).toList();
        int startY=contentY+39, colW=(pw-205)/2, rowH=53;
        int maxRows=Math.max(1,(ph-150)/rowH);
        for(int i=0;i<visible.size();i++){
            int col=i/maxRows, row=i%maxRows;
            int x=contentX+col*(colW+10), y=startY+row*rowH-scroll;
            if(y<contentY+30||y+46>py+ph-15) continue;
            ModuleManager.VisualModule m=visible.get(i);
            ctx.fill(x,y,x+colW,y+46, selected==i?0xFF252336:0xFF191B26);
            ctx.drawTextWithShadow(textRenderer,Text.literal(m.name),x+11,y+8,0xFFF0EEF8);
            ctx.drawTextWithShadow(textRenderer,Text.literal(m.description),x+11,y+25,0xFF858397);
            int sx=x+colW-48, sy=y+14;
            ctx.fill(sx,sy,sx+36,sy+17,m.enabled?PURPLE:0xFF393B49);
            ctx.fill(m.enabled?sx+20:sx+3,sy+3,m.enabled?sx+33:sx+16,sy+14,0xFFF2EDFF);
        }

        // Settings drawer for selected module
        if(selected>=0 && selected<visible.size()){
            ModuleManager.VisualModule m=visible.get(selected);
            int dx=px+pw-204, dy=py+ph-127;
            ctx.fill(dx,dy,px+pw-14,py+ph-14,0xFF211D2D);
            ctx.drawTextWithShadow(textRenderer,Text.literal("SETTINGS  •  "+m.name),dx+10,dy+10,0xFFD6BEFF);
            drawSlider(ctx,dx+10,dy+31,166,m.settingOneName,m.settingOne);
            drawSlider(ctx,dx+10,dy+69,166,m.settingTwoName,m.settingTwo);
        }
        super.render(ctx,mouseX,mouseY,delta);
    }

    private void drawSlider(DrawContext ctx,int x,int y,int w,String label,float value){
        ctx.drawTextWithShadow(textRenderer,Text.literal(label),x,y,0xFFB9B5C8);
        ctx.drawTextWithShadow(textRenderer,Text.literal(Integer.toString((int)value)),x+w-22,y,0xFFD2B8FF);
        ctx.fill(x,y+15,x+w,y+19,0xFF454052);
        ctx.fill(x,y+15,x+(int)(w*value/100f),y+19,PURPLE);
        ctx.fill(x+(int)(w*value/100f)-3,y+12,x+(int)(w*value/100f)+3,y+22,0xFFE9DFFF);
    }

    @Override public boolean mouseClicked(double mx,double my,int button){
        int navX=px+14, navY=py+76;
        for(int i=0;i<TABS.length;i++){
            int y=navY+34+i*36;
            if(mx>=navX+7&&mx<=navX+143&&my>=y-5&&my<=y+21){tab=i;scroll=0;selected=-1;return true;}
        }
        int contentX=px+178, contentY=py+79, startY=contentY+39;
        int colW=(pw-205)/2, rowH=53, maxRows=Math.max(1,(ph-150)/rowH);
        visible=ModuleManager.MODULES.stream().filter(m->m.category.equals(TABS[tab])).toList();
        for(int i=0;i<visible.size();i++){
            int col=i/maxRows,row=i%maxRows,x=contentX+col*(colW+10),y=startY+row*rowH-scroll;
            if(mx>=x&&mx<=x+colW&&my>=y&&my<=y+46){
                selected=i;
                if(button==1) return true;
                visible.get(i).enabled=!visible.get(i).enabled;
                return true;
            }
        }
        if(selected>=0 && selected<visible.size() && button==0){
            ModuleManager.VisualModule m=visible.get(selected);
            int dx=px+pw-204,dy=py+ph-127;
            if(mx>=dx+10&&mx<=dx+176&&my>=dy+43&&my<=dy+57){
                m.settingOne=Math.max(0,Math.min(100,(float)((mx-(dx+10))/166*100)));return true;
            }
            if(mx>=dx+10&&mx<=dx+176&&my>=dy+81&&my<=dy+95){
                m.settingTwo=Math.max(0,Math.min(100,(float)((mx-(dx+10))/166*100)));return true;
            }
        }
        return true;
    }

    @Override public boolean mouseScrolled(double mx,double my,double h,double v){
        scroll=Math.max(0,Math.min(500,scroll-(int)(v*24)));return true;
    }
    @Override public boolean keyPressed(int key,int scan,int mods){
        if(key==GLFW.GLFW_KEY_ESCAPE||key==GLFW.GLFW_KEY_RIGHT_SHIFT){close();return true;}
        return super.keyPressed(key,scan,mods);
    }
}
