package dev.aurora.visuals;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class AuroraVisualsClient implements ClientModInitializer {
    public static final String MOD_NAME = "AURORA VISUALS";
    private KeyBinding openGui;
    private int weatherTick;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.aurora_visuals.open_gui", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT, "category.aurora_visuals"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGui.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new VisualsScreen());
            }
            if (client.player == null || client.world == null || client.currentScreen != null) return;
            weatherTick++;
            // Local-only ambience: does not change server weather or affect other players.
            if (weatherTick % 2 == 0 && enabled("Snow")) {
                double x = client.player.getX() + (client.world.random.nextDouble() - .5) * 18;
                double z = client.player.getZ() + (client.world.random.nextDouble() - .5) * 18;
                double y = client.player.getY() + 7 + client.world.random.nextDouble() * 5;
                client.world.addParticle(ParticleTypes.SNOWFLAKE, x, y, z, 0, -.12, 0);
            }
            if (weatherTick % 2 == 0 && enabled("Weather") && client.world.isRaining()) {
                double x = client.player.getX() + (client.world.random.nextDouble() - .5) * 16;
                double z = client.player.getZ() + (client.world.random.nextDouble() - .5) * 16;
                double y = client.player.getY() + 8;
                client.world.addParticle(ParticleTypes.RAIN, x, y, z, 0, -.25, 0);
            }
        });

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            var client = net.minecraft.client.MinecraftClient.getInstance();
            if (client.player == null || client.options.hudHidden) return;
            int y = 8;
            if (enabled("Watermark")) {
                drawContext.fill(8, y - 3, 132, y + 13, 0x990D0F18);
                drawContext.fill(8, y - 3, 10, y + 13, 0xFF8957FF);
                drawContext.drawTextWithShadow(client.textRenderer, Text.literal("✦ AURORA"), 15, y, 0xFFD8BEFF);
                y += 20;
            }
            if (enabled("FPS Counter")) {
                drawContext.drawTextWithShadow(client.textRenderer, Text.literal("FPS: " + client.getCurrentFps()), 9, y, 0xFFFFFFFF);
                y += 11;
            }
            if (enabled("Coordinates")) {
                var p = client.player.getBlockPos();
                drawContext.drawTextWithShadow(client.textRenderer,
                        Text.literal("XYZ: " + p.getX() + " / " + p.getY() + " / " + p.getZ()),
                        9, y, 0xFFFFFFFF);
            }
        });
    }

    private static boolean enabled(String name) {
        var module = ModuleManager.get(name);
        return module != null && module.enabled;
    }
}
