# Aurora Visuals — Minecraft 1.21.4 Fabric

Pulse Visuals-inspired client-side visual mod.

## Controls
- Right Shift: open/close GUI
- Left click a module: toggle it
- Right click a module: select its settings
- Click either settings slider to adjust its value

## Actual client-side effects in this build
- **See Invisible**: client mixin changes the local visibility test for living entities.
- **Target ESP**: renders colored bounding-box outlines around nearby living entities (players in pink, other living entities in purple).
- **Trails**: records short local position histories and renders fading purple markers.
- **World Particles**: emits a small amount of local ambient end-rod particles around the player.

All effects are client-side. They do not grant server permissions, reveal entities that the server does not send to the client, or change server gameplay.

## Menu/config framework
The menu also contains the Pulse-inspired module catalogue: Hit Bubble, Hit Color, Hit Range,
Hitbox Customizer, Item Physic, Jump Circles, Kill Effect, Motion Blur, Nimb, No Fluid,
Particles, Render Tweaks, Self Nametag, Weather, Puddles, Rain Reflections, Snow, Thunder,
Fog, Wind, Tab Customizer, Watermark, FPS Counter, Coordinates, Totem Effect, Totem Counter,
Sound Effects, Menu Blur, Gui Particles and Animations.

Those remaining entries are UI/config placeholders for future implementation; their toggles do not yet implement those effects.

## Build
Requires Java 21, Gradle, Fabric Loader and Fabric API for Minecraft 1.21.4.
Run `gradle build`; the mod jar is created in `build/libs/`.

## Additional working effects in this build
- Watermark, FPS Counter and Coordinates render in the HUD when enabled.
- Snow emits local snow particles around the player.
- Weather emits local rain particles while the server world is raining.
These weather particles are client-only ambience and do not change the server's weather.
