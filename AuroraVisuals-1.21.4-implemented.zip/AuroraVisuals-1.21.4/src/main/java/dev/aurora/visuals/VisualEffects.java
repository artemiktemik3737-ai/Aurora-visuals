package dev.aurora.visuals;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexRendering;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * Client-only visual effects. No packets are sent and no server state is changed.
 */
public final class VisualEffects {
    private static final Map<UUID, ArrayDeque<Vec3d>> TRAILS = new HashMap<>();
    private static int tick;
    private VisualEffects() {}

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> tick(client));
        WorldRenderEvents.AFTER_ENTITIES.register(VisualEffects::renderWorld);
    }

    private static boolean enabled(String name) {
        ModuleManager.VisualModule m = ModuleManager.get(name);
        return m != null && m.enabled;
    }

    private static void tick(MinecraftClient client) {
        if (client.world == null || client.player == null) {
            TRAILS.clear();
            return;
        }
        tick++;

        if (enabled("Trails")) {
            for (Entity entity : client.world.getEntities()) {
                if (!(entity instanceof LivingEntity living) || entity == client.player || !entity.isAlive()) continue;
                ArrayDeque<Vec3d> points = TRAILS.computeIfAbsent(entity.getUuid(), id -> new ArrayDeque<>());
                Vec3d p = entity.getPos().add(0, 0.08, 0);
                if (points.isEmpty() || points.getLast().squaredDistanceTo(p) > 0.035) {
                    points.addLast(p);
                    while (points.size() > 24) points.removeFirst();
                }
            }
        } else {
            TRAILS.clear();
        }

        // A light local particle ambience; only visible to this client.
        if (enabled("World Particles") && tick % 7 == 0) {
            double x = client.player.getX() + (client.world.random.nextDouble() - 0.5) * 9.0;
            double y = client.player.getY() + 0.8 + client.world.random.nextDouble() * 3.0;
            double z = client.player.getZ() + (client.world.random.nextDouble() - 0.5) * 9.0;
            client.world.addParticle(ParticleTypes.END_ROD, x, y, z, 0, 0.012, 0);
        }

        // Prune trail history for entities no longer present.
        if (tick % 100 == 0) {
            Iterator<UUID> it = TRAILS.keySet().iterator();
            while (it.hasNext()) {
                UUID id = it.next();
                boolean exists = client.world.getEntities().stream().anyMatch(e -> e.getUuid().equals(id));
                if (!exists) it.remove();
            }
        }
    }

    private static void renderWorld(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null || client.player == null || context.matrixStack() == null || context.consumers() == null) return;
        boolean esp = enabled("Target ESP");
        boolean trails = enabled("Trails");
        if (!esp && !trails) return;

        Vec3d camera = context.camera().getPos();
        var matrices = context.matrixStack();
        VertexConsumerProvider consumers = context.consumers();
        VertexConsumer lines = consumers.getBuffer(RenderLayer.getLines());

        matrices.push();
        matrices.translate(-camera.x, -camera.y, -camera.z);

        if (esp) {
            Box search = client.player.getBoundingBox().expand(48);
            for (LivingEntity entity : client.world.getEntitiesByClass(
                    LivingEntity.class, search, e -> e != client.player && e.isAlive())) {
                Box box = entity.getBoundingBox().expand(0.035);
                int color = entity instanceof PlayerEntity ? 0xFFFF526A : 0xFF8D72FF;
                VertexRendering.drawBox(matrices, lines, box,
                        ((color >> 16) & 255) / 255.0f,
                        ((color >> 8) & 255) / 255.0f,
                        (color & 255) / 255.0f, 0.92f);
            }
        }

        if (trails) {
            for (ArrayDeque<Vec3d> points : TRAILS.values()) {
                int n = points.size();
                int i = 0;
                Vec3d previous = null;
                for (Vec3d p : points) {
                    float fade = (float) (++i) / Math.max(1, n);
                    if (previous != null) {
                        // Small linked boxes form a dotted, fading trail in the world.
                        Vec3d mid = previous.lerp(p, 0.5);
                        double r = 0.025 + fade * 0.025;
                        Box marker = new Box(mid.x-r, mid.y-r, mid.z-r, mid.x+r, mid.y+r, mid.z+r);
                        VertexRendering.drawBox(matrices, lines, marker, 0.58f, 0.34f, 1.0f, fade * 0.9f);
                    }
                    previous = p;
                }
            }
        }
        matrices.pop();
    }
}
