package dev.aurora.visuals.mixin;

import dev.aurora.visuals.AuroraMainMenuScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin {
    @Inject(method = "init", at = @At("HEAD"), cancellable = true)
    private void aurora$replaceVanillaMenu(CallbackInfo ci) {
        ci.cancel();
        MinecraftClient.getInstance().setScreen(new AuroraMainMenuScreen());
    }
}
