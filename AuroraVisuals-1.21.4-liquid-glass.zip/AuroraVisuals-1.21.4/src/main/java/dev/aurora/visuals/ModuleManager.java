package dev.aurora.visuals;

import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    public static final List<VisualModule> MODULES = new ArrayList<>();
    private ModuleManager() {}

    public static void init() {
        if (!MODULES.isEmpty()) return;
        // Names and categories are based on the supplied Pulse Visuals screenshots.
        add("Hit Bubble", "Bubble effect around a hit", "Visuals", false, "Effect size", "Opacity");
        add("Hit Color", "Custom color when hitting an entity", "Visuals", true, "Color intensity", "Duration");
        add("Hit Range", "Visual indicator for hit range", "Visuals", false, "Range", "Opacity");
        add("Hitbox Customizer", "Customize hitbox outline visuals", "Visuals", false, "Line width", "Opacity");
        add("Item Physic", "Visual item drop physics", "Visuals", true, "Rotation", "Bounce");
        add("Jump Circles", "Circles when entities jump", "Visuals", true, "Radius", "Duration");
        add("Kill Effect", "Visual effect when an entity is defeated", "Visuals", true, "Scale", "Duration");
        add("Nimb", "Nimbus-style ambient visual effect", "Visuals", true, "Density", "Size");
        add("No Fluid", "Hide fluid screen overlay", "Visuals", false, "Opacity", "Distortion");
        add("Particles", "Customize world particles", "Visuals", true, "Density", "Size");
        add("Render Tweaks", "Extra rendering adjustments", "Visuals", true, "Brightness", "Distance");
        add("Self Nametag", "Show your own nametag", "Visuals", false, "Scale", "Opacity");
        add("Target ESP", "Outline nearby living entities", "Visuals", false, "Width", "Opacity");
        add("Trails", "Fading trails behind moving entities", "Visuals", false, "Length", "Fade");
        add("See Invisible", "Render invisible living entities locally", "Visuals", false, "Opacity", "Glow");
        add("Weather", "Local weather visual controls", "World", false, "Intensity", "Wind");
        add("World Particles", "Ambient particles in the world", "World", false, "Density", "Lifetime");
        add("Puddles", "Rain puddle visual controls", "World", false, "Amount", "Reflection");
        add("Rain Reflections", "Reflection effect on wet surfaces", "World", false, "Strength", "Blur");
        add("Snow", "Snowfall visual controls", "World", false, "Density", "Wind");
        add("Thunder", "Lightning and thunder ambience", "World", false, "Frequency", "Brightness");
        add("Fog", "Atmospheric fog controls", "World", false, "Density", "Distance");
        add("Wind", "Wind ambience and particle direction", "World", false, "Strength", "Variation");
        add("Tab Customizer", "Customize player list appearance", "HUD", false, "Scale", "Background");
        add("Watermark", "Client watermark on screen", "HUD", false, "Scale", "Opacity");
        add("FPS Counter", "Display FPS counter", "HUD", false, "Scale", "Opacity");
        add("Coordinates", "Display player coordinates", "HUD", false, "Scale", "Opacity");
        add("Totem Effect", "Customize totem activation visuals", "Effects", false, "Size", "Duration");
        add("Totem Counter", "Show remaining totems", "Effects", false, "Scale", "Opacity");
        add("Sound Effects", "Visual module sound feedback", "Effects", false, "Volume", "Pitch");
        add("Gui Particles", "Particles inside the click GUI", "Interface", false, "Density", "Speed");
        add("Animations", "Smooth menu and toggle animations", "Interface", true, "Speed", "Scale");
    }

    private static void add(String n, String d, String c, boolean e, String s1, String s2) {
        MODULES.add(new VisualModule(n, d, c, e, s1, s2));
    }
    public static VisualModule get(String name) {
        return MODULES.stream().filter(m -> m.name.equals(name)).findFirst().orElse(null);
    }

    public static final class VisualModule {
        public final String name, description, category, settingOneName, settingTwoName;
        public boolean enabled;
        public float settingOne = 50, settingTwo = 50;
        public VisualModule(String name, String description, String category, boolean enabled, String s1, String s2) {
            this.name=name; this.description=description; this.category=category; this.enabled=enabled;
            this.settingOneName=s1; this.settingTwoName=s2;
        }
    }
}
