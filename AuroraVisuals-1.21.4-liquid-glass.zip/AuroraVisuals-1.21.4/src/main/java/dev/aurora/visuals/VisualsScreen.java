package dev.aurora.visuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.List;

/** Clean, sharp Aurora click-GUI. No blur, no translucent backdrop. */
public class VisualsScreen extends Screen {
    private static final String[] TABS = {"Visuals", "World", "HUD", "Effects", "Interface"};
    private static final int ACCENT = 0xFFB58CFF;
    private static final int PANEL = 0xFF171923;
    private static final int CARD = 0xFF20232E;
    private static final int MUTED = 0xFF9298AA;
    private int tab, scroll, selected = -1;
    private int px, py, pw, ph;
    private List<ModuleManager.VisualModule> visible = List.of();

    public VisualsScreen() { super(Text.literal("Aurora Visuals")); }
    @Override public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // Deliberately keep the game world crisp: no blur and no dark fullscreen overlay.
        pw = Math.min(760, width - 32);
        ph = Math.min(440, height - 32);
        px = (width - pw) / 2;
        py = (height - ph) / 2;

        rounded(ctx, px, py, px + pw, py + ph, 14, 0xF5101219);
        rounded(ctx, px + 1, py + 1, px + pw - 1, py + 58, 13, 0xFF1C1F2A);
        ctx.fill(px + 16, py + 57, px + pw - 16, py + 58, 0xFF303342);

        // Header
        rounded(ctx, px + 18, py + 16, px + 40, py + 38, 7, ACCENT);
        ctx.drawText(textRenderer, Text.literal("A"), px + 25, py + 22, 0xFF17131F, false);
        ctx.drawText(textRenderer, Text.literal("AURORA"), px + 50, py + 15, 0xFFF5F3FA, false);
        ctx.drawText(textRenderer, Text.literal("VISUAL CLIENT  /  1.21.4"), px + 50, py + 30, MUTED, false);
        ctx.drawText(textRenderer, Text.literal("RIGHT SHIFT  ·  CLOSE"), px + pw - 155, py + 25, MUTED, false);

        // Navigation rail
        int navX = px + 16, navY = py + 76;
        ctx.drawText(textRenderer, Text.literal("MENU"), navX + 10, navY, MUTED, false);
        for (int i = 0; i < TABS.length; i++) {
            int y = navY + 22 + i * 34;
            boolean active = i == tab;
            if (active) rounded(ctx, navX, y - 5, navX + 126, y + 23, 8, 0xFF343044);
            ctx.drawText(textRenderer, Text.literal(TABS[i]), navX + 12, y + 3,
                    active ? ACCENT : 0xFFB9BDCA, false);
            if (active) rounded(ctx, navX + 2, y + 2, navX + 5, y + 16, 2, ACCENT);
        }
        ctx.drawText(textRenderer, Text.literal("FABRIC 1.21.4"), navX + 8, py + ph - 25, MUTED, false);

        // Module list
        int contentX = px + 164, contentY = py + 78;
        ctx.drawText(textRenderer, Text.literal(TABS[tab].toUpperCase()), contentX, contentY, 0xFFF3F1F8, false);
        ctx.drawText(textRenderer, Text.literal("Click to toggle  ·  Right-click for settings"), contentX, contentY + 15, MUTED, false);
        visible = ModuleManager.MODULES.stream().filter(m -> m.category.equals(TABS[tab])).toList();
        int startY = contentY + 40;
        int gap = 9;
        int colW = Math.max(120, (pw - 198) / 2);
        int rowH = 58;
        int maxRows = Math.max(1, (ph - 146) / rowH);
        for (int i = 0; i < visible.size(); i++) {
            int col = i / maxRows, row = i % maxRows;
            int x = contentX + col * (colW + gap);
            int y = startY + row * rowH - scroll;
            if (y < contentY + 30 || y + 51 > py + ph - 14) continue;
            ModuleManager.VisualModule m = visible.get(i);
            boolean hover = mouseX >= x && mouseX <= x + colW && mouseY >= y && mouseY <= y + 49;
            int bg = selected == i ? 0xFF302B40 : (hover ? 0xFF292D3A : CARD);
            rounded(ctx, x, y, x + colW, y + 49, 9, bg);
            ctx.drawText(textRenderer, Text.literal(m.name), x + 11, y + 9, 0xFFF0EFF5, false);
            ctx.drawText(textRenderer, Text.literal(m.description), x + 11, y + 26, MUTED, false);
            // Compact pill switch
            int sx = x + colW - 43, sy = y + 16;
            rounded(ctx, sx, sy, sx + 32, sy + 17, 9, m.enabled ? ACCENT : 0xFF444957);
            rounded(ctx, m.enabled ? sx + 18 : sx + 3, sy + 3, m.enabled ? sx + 29 : sx + 14, sy + 14, 6, 0xFFF9F7FF);
        }

        // Selected module settings, anchored at bottom right and kept compact.
        if (selected >= 0 && selected < visible.size()) {
            ModuleManager.VisualModule m = visible.get(selected);
            int dx = px + pw - 224, dy = py + ph - 116;
            rounded(ctx, dx, dy, px + pw - 14, py + ph - 14, 10, 0xFF292638);
            ctx.drawText(textRenderer, Text.literal(m.name + "  SETTINGS"), dx + 12, dy + 10, ACCENT, false);
            drawSlider(ctx, dx + 12, dy + 31, 174, m.settingOneName, m.settingOne);
            drawSlider(ctx, dx + 12, dy + 70, 174, m.settingTwoName, m.settingTwo);
        }
        super.render(ctx, mouseX, mouseY, delta);
    }

    private void drawSlider(DrawContext ctx, int x, int y, int w, String label, float value) {
        ctx.drawText(textRenderer, Text.literal(label), x, y, 0xFFD0CEDA, false);
        ctx.drawText(textRenderer, Text.literal(Integer.toString((int) value)), x + w - 20, y, ACCENT, false);
        int sx = x, sy = y + 16, knob = sx + (int) (w * value / 100f);
        rounded(ctx, sx, sy, sx + w, sy + 4, 2, 0xFF4A4B59);
        rounded(ctx, sx, sy, knob, sy + 4, 2, ACCENT);
        rounded(ctx, knob - 4, sy - 3, knob + 4, sy + 7, 4, 0xFFF5F0FF);
    }

    private static void rounded(DrawContext ctx, int x1, int y1, int x2, int y2, int r, int color) {
        int radius = Math.max(0, Math.min(r, Math.min((x2 - x1) / 2, (y2 - y1) / 2)));
        for (int y = 0; y < y2 - y1; y++) {
            int inset = 0;
            if (y < radius) {
                double dy = radius - y - 0.5;
                inset = radius - (int) Math.floor(Math.sqrt(Math.max(0, radius * radius - dy * dy)));
            } else if (y >= y2 - y1 - radius) {
                double dy = y - (y2 - y1 - radius) + 0.5;
                inset = radius - (int) Math.floor(Math.sqrt(Math.max(0, radius * radius - dy * dy)));
            }
            ctx.fill(x1 + inset, y1 + y, x2 - inset, y1 + y + 1, color);
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int navX = px + 16, navY = py + 76;
        for (int i = 0; i < TABS.length; i++) {
            int y = navY + 22 + i * 34;
            if (mx >= navX && mx <= navX + 126 && my >= y - 5 && my <= y + 23) {
                tab = i; scroll = 0; selected = -1; return true;
            }
        }
        int contentX = px + 164, contentY = py + 78, startY = contentY + 40;
        int colW = Math.max(120, (pw - 198) / 2), maxRows = Math.max(1, (ph - 146) / 58);
        visible = ModuleManager.MODULES.stream().filter(m -> m.category.equals(TABS[tab])).toList();
        for (int i = 0; i < visible.size(); i++) {
            int col = i / maxRows, row = i % maxRows;
            int x = contentX + col * (colW + 9), y = startY + row * 58 - scroll;
            if (mx >= x && mx <= x + colW && my >= y && my <= y + 49) {
                selected = i;
                if (button == 1) return true;
                visible.get(i).enabled = !visible.get(i).enabled;
                return true;
            }
        }
        if (selected >= 0 && selected < visible.size() && button == 0) {
            ModuleManager.VisualModule m = visible.get(selected);
            int dx = px + pw - 224, dy = py + ph - 116;
            if (mx >= dx + 12 && mx <= dx + 186 && my >= dy + 44 && my <= dy + 54) {
                m.settingOne = Math.max(0, Math.min(100, (float) ((mx - (dx + 12)) / 174 * 100))); return true;
            }
            if (mx >= dx + 12 && mx <= dx + 186 && my >= dy + 83 && my <= dy + 93) {
                m.settingTwo = Math.max(0, Math.min(100, (float) ((mx - (dx + 12)) / 174 * 100))); return true;
            }
        }
        return true;
    }

    @Override public boolean mouseScrolled(double mx, double my, double h, double v) {
        scroll = Math.max(0, Math.min(500, scroll - (int) (v * 24))); return true;
    }
    @Override public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
        return super.keyPressed(key, scan, mods);
    }
}
