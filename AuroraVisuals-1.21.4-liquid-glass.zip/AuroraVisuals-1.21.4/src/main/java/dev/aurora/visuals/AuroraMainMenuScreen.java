package dev.aurora.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/** Aurora's custom Liquid Glass home screen. */
public final class AuroraMainMenuScreen extends Screen {
    private static final int[] ACCENTS = {0xFFB58CFF, 0xFF78D9FF, 0xFFFF91C8, 0xFF8DE8B4, 0xFFFFC77D};
    private static final String[] ACCENT_NAMES = {"Violet", "Arctic", "Rose", "Mint", "Amber"};
    public static int accentIndex = 0;
    private int panelX, panelY, panelW, panelH;
    private int hover = -1;
    private float pulse;

    public AuroraMainMenuScreen() { super(Text.literal("Aurora")); }
    public static int accent() { return ACCENTS[accentIndex]; }
    @Override public boolean shouldPause() { return false; }

    @Override public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        pulse += delta * .025f;
        // Preserve the vanilla panorama; add only a light tint, never a fullscreen blur.
        ctx.fill(0, 0, width, height, 0x3A080B16);
        int w = Math.min(820, width - 36), h = Math.min(470, height - 30);
        panelW = w; panelH = h; panelX = (width - w) / 2; panelY = (height - h) / 2;
        glass(ctx, panelX, panelY, panelX + w, panelY + h, 0xB8171B2B, 0x66FFFFFF);
        glass(ctx, panelX + 18, panelY + 18, panelX + w - 18, panelY + 76, 0x662B3045, 0x44FFFFFF);
        // Specular edge and restrained ambient glow.
        ctx.fill(panelX + 30, panelY + 19, panelX + w - 30, panelY + 20, 0x55FFFFFF);
        ctx.fill(panelX + 1, panelY + 28, panelX + 2, panelY + h - 28, accent());

        ctx.drawText(textRenderer, "✦", panelX + 34, panelY + 37, accent(), true);
        ctx.drawText(textRenderer, "AURORA", panelX + 56, panelY + 31, 0xFFF7F5FF, true);
        ctx.drawText(textRenderer, "LIQUID GLASS  •  1.21.4", panelX + 56, panelY + 48, 0xFFB7B8CB, false);
        String player = MinecraftClient.getInstance().getSession().getUsername();
        ctx.drawText(textRenderer, "PROFILE  /  " + player, panelX + w - 190, panelY + 41, 0xFFD6D5E4, false);

        int left = panelX + 34, top = panelY + 108;
        ctx.drawText(textRenderer, "WELCOME BACK", left, top, 0xFFB7B8CB, false);
        ctx.drawText(textRenderer, "Your world. Your atmosphere.", left, top + 20, 0xFFF8F6FF, true);
        ctx.drawText(textRenderer, "Choose where to go — everything in one calm space.", left, top + 39, 0xFFB7B8CB, false);

        int bx = left, by = top + 82, bw = Math.min(330, w / 2 - 55), bh = 48, gap = 12;
        drawButton(ctx, 0, bx, by, bw, bh, "Singleplayer", "Create or open a world", mouseX, mouseY, true);
        drawButton(ctx, 1, bx, by + bh + gap, bw, bh, "Multiplayer", "Servers and direct connect", mouseX, mouseY, false);
        drawButton(ctx, 2, bx, by + (bh + gap) * 2, bw, bh, "Accounts", "Current profile and account help", mouseX, mouseY, false);
        drawButton(ctx, 3, bx, by + (bh + gap) * 3, bw, bh, "Settings", "Game options and appearance", mouseX, mouseY, false);

        int rx = panelX + w - 245, ry = top + 80;
        glass(ctx, rx, ry, panelX + w - 30, ry + 228, 0x71323850, 0x55FFFFFF);
        ctx.drawText(textRenderer, "YOUR AURORA", rx + 17, ry + 17, 0xFFF8F6FF, true);
        ctx.drawText(textRenderer, "COLOR ATMOSPHERE", rx + 17, ry + 42, 0xFFB7B8CB, false);
        String[] names = {"Violet", "Arctic", "Rose", "Mint", "Amber"};
        for (int i = 0; i < ACCENTS.length; i++) {
            int cx = rx + 23 + i * 35, cy = ry + 70;
            circle(ctx, cx, cy, 10, ACCENTS[i]);
            if (i == accentIndex) circle(ctx, cx, cy, 3, 0xFFFFFFFF);
        }
        ctx.drawText(textRenderer, "ACTIVE THEME", rx + 17, ry + 96, 0xFFB7B8CB, false);
        ctx.drawText(textRenderer, names[accentIndex], rx + 17, ry + 113, accent(), true);
        ctx.fill(rx + 17, ry + 139, rx + 195, ry + 140, 0x33FFFFFF);
        ctx.drawText(textRenderer, "GLASS SURFACE", rx + 17, ry + 154, 0xFFB7B8CB, false);
        ctx.drawText(textRenderer, "Translucent • Soft edge", rx + 17, ry + 171, 0xFFE4E1F0, false);
        ctx.drawText(textRenderer, "RIGHT SHIFT  ·  VISUALS", rx + 17, ry + 199, 0xFFAAAABD, false);

        ctx.drawText(textRenderer, "AURORA VISUALS", panelX + 34, panelY + h - 27, 0xFFB7B8CB, false);
        ctx.drawText(textRenderer, "Made to feel like home", panelX + w - 170, panelY + h - 27, 0xFFB7B8CB, false);
        super.render(ctx, mouseX, mouseY, delta);
    }

    private void drawButton(DrawContext ctx, int id, int x, int y, int w, int h, String title, String sub, int mx, int my, boolean primary) {
        boolean over = mx >= x && mx <= x + w && my >= y && my <= y + h;
        if (over) hover = id;
        int bg = primary ? 0x663F3A5C : (over ? 0x66464A62 : 0x44343A50);
        glass(ctx, x, y, x + w, y + h, bg, over ? 0x99FFFFFF : 0x44FFFFFF);
        if (primary) ctx.fill(x + 1, y + 8, x + 3, y + h - 8, accent());
        ctx.drawText(textRenderer, title, x + 15, y + 9, 0xFFF8F6FF, true);
        ctx.drawText(textRenderer, sub, x + 15, y + 26, 0xFFB7B8CB, false);
        ctx.drawText(textRenderer, "›", x + w - 20, y + 14, primary ? accent() : 0xFFD6D5E4, true);
    }

    static void glass(DrawContext c, int x1, int y1, int x2, int y2, int fill, int edge) {
        rounded(c, x1, y1, x2, y2, 13, fill);
        c.fill(x1 + 12, y1, x2 - 12, y1 + 1, edge);
        c.fill(x1, y1 + 12, x1 + 1, y2 - 12, edge);
        c.fill(x2 - 1, y1 + 12, x2, y2 - 12, 0x22FFFFFF);
    }
    private static void circle(DrawContext c, int x, int y, int r, int color) {
        for (int dy = -r; dy <= r; dy++) { int dx = (int)Math.sqrt(r*r - dy*dy); c.fill(x-dx, y+dy, x+dx+1, y+dy+1, color); }
    }
    private static void rounded(DrawContext c, int x1, int y1, int x2, int y2, int r, int color) {
        for (int y = y1; y < y2; y++) { int dy = y < y1+r ? r-(y-y1) : y >= y2-r ? r-(y2-y-1) : 0; int inset = dy > 0 ? r-(int)Math.floor(Math.sqrt(Math.max(0, r*r-dy*dy))) : 0; c.fill(x1+inset,y,x2-inset,y+1,color); }
    }

    @Override public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return super.mouseClicked(mx, my, button);
        int left = panelX + 34, top = panelY + 108, bw = Math.min(330, panelW / 2 - 55), bh = 48, gap = 12, by = top + 82;
        if (mx >= left && mx <= left+bw && my >= by && my <= by+bh) { client.setScreen(new SelectWorldScreen(this)); return true; }
        if (mx >= left && mx <= left+bw && my >= by+bh+gap && my <= by+2*bh+gap) { client.setScreen(new MultiplayerScreen(this)); return true; }
        if (mx >= left && mx <= left+bw && my >= by+2*(bh+gap) && my <= by+3*bh+2*gap) { client.setScreen(new AccountInfoScreen(this)); return true; }
        if (mx >= left && mx <= left+bw && my >= by+3*(bh+gap) && my <= by+4*bh+3*gap) { client.setScreen(new OptionsScreen(this, client.options)); return true; }
        int rx = panelX + panelW - 245, ry = top + 80;
        for (int i=0;i<ACCENTS.length;i++) { int cx=rx+23+i*35, cy=ry+70; if (Math.hypot(mx-cx,my-cy)<=12) { accentIndex=i; return true; } }
        return true;
    }
    @Override public boolean keyPressed(int key, int scan, int mods) { if (key == GLFW.GLFW_KEY_ESCAPE) { return true; } return super.keyPressed(key, scan, mods); }
}
