package dev.aurora.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/** Account overview. Minecraft authentication itself is managed by the launcher. */
public final class AccountInfoScreen extends Screen {
    private final Screen parent;
    public AccountInfoScreen(Screen parent) { super(Text.literal("Aurora Accounts")); this.parent = parent; }
    @Override public boolean shouldPause() { return false; }
    @Override public void render(DrawContext c, int mx, int my, float delta) {
        c.fill(0,0,width,height,0x55080B16);
        int w=Math.min(440,width-32), h=230, x=(width-w)/2, y=(height-h)/2;
        AuroraMainMenuScreen.glass(c,x,y,x+w,y+h,0xD51A2031,0x77FFFFFF);
        c.drawText(textRenderer,"ACCOUNT PROFILE",x+24,y+24,0xFFF8F6FF,true);
        c.drawText(textRenderer,"CURRENT JAVA SESSION",x+24,y+62,0xFFB7B8CB,false);
        c.drawText(textRenderer,MinecraftClient.getInstance().getSession().getUsername(),x+24,y+82,AuroraMainMenuScreen.accent(),true);
        c.drawText(textRenderer,"To add or switch Microsoft accounts, use your Minecraft launcher.",x+24,y+119,0xFFE0DEEA,false);
        c.drawText(textRenderer,"Aurora reads the active game profile; it never stores passwords.",x+24,y+137,0xFFB7B8CB,false);
        AuroraMainMenuScreen.glass(c,x+24,y+h-54,x+w-24,y+h-20,0x66403B5C,0x66FFFFFF);
        c.drawText(textRenderer,"BACK",x+w/2-13,y+h-43,0xFFF8F6FF,true);
        super.render(c,mx,my,delta);
    }
    @Override public boolean mouseClicked(double mx,double my,int button) { if(button==0){close();return true;} return super.mouseClicked(mx,my,button); }
    @Override public void close(){ client.setScreen(parent); }
    @Override public boolean keyPressed(int key,int scan,int mods){if(key==GLFW.GLFW_KEY_ESCAPE){close();return true;}return super.keyPressed(key,scan,mods);}
}
