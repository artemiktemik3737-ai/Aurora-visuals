# Aurora Visuals — Minecraft 1.21.4 Fabric

Client-side Fabric mod with a custom Aurora Liquid Glass title screen, visual module screen, HUD, and local visual effects.

## Main menu
- Custom translucent layered glass-style main screen replacing the vanilla title screen.
- Singleplayer opens the vanilla world selector.
- Multiplayer opens the vanilla server list and direct-connect flow.
- Settings opens vanilla game options.
- Accounts shows the active game profile. Account authentication/switching is intentionally delegated to the official launcher; the mod does not handle or store Microsoft credentials.
- Five selectable accent palettes.

The glass effect is implemented with translucent layers, subtle highlights, and borders. It does not apply a costly fullscreen blur shader.

## Build
Java 21, Gradle 8.12.1, Fabric Loom 1.9.x. Run `gradle build`.

This source has not yet been compiled or tested in a live Minecraft client in this environment. Verify the GitHub Actions build before installing.
